const express = require('express');
const app = express();
const path = require('path');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const cookieParser = require('cookie-parser');
const nodemailer = require('nodemailer');
const serverless = require('serverless-http');
require('dotenv').config();  

const usermodel = require('./models/user');
const jobpostmodel = require('./models/jobpost');
const { log } = require('console');



app.use(express.static(path.join(__dirname, 'public')));
app.use(express.urlencoded({ extended: true })); 
app.use(express.json()); 
app.use(cookieParser());

app.set('view engine', 'ejs');

// Middleware to protect routes
const authMiddleware = (req, res, next) => {
    const token = req.cookies.token;
    if (!token) {
        return res.status(401).redirect("/");
    }

    try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        req.user = decoded;
        next();
    } catch (err) {
        console.error("JWT Verification Error:", err);
        return res.status(401).send("Invalid or expired token");
    }
};

// Role-based access middleware
const isAdmin = (allowedRoles) => {
    return (req, res, next) => {
        if (!req.user || !allowedRoles.includes(req.user.role)) {
            return res.status(403).send("You do not have permission");
        }
        next();
    };
};

// Home Page
app.get('/', (req, res) => {
    res.render('index.ejs');
});

app.post('/login', async (req, res) => {
    
    if (!req.body.email) {
        return res.alart("Email is missing in request body");
    }

    try {
        const user = await usermodel.findOne({ email: req.body.email });
        if (!user) {
            return res.send("User not found");
        }

        const result = await bcrypt.compare(req.body.password, user.password);
        if (result) {
            const token = jwt.sign({ id: user._id, role: user.role }, process.env.JWT_SECRET);
            res.cookie('token', token, { httpOnly: true });

            if (user.role === 'Worker') {
                res.redirect('/worker');
            } else if (user.role === 'Client') {
                res.redirect('/client');
            }
        } else {
            res.send("Invalid password");
        }
    } catch (err) {
        console.error("Login Error:", err);
        res.status(500).send("Something went wrong, please try again later.");
    }
});

// Logout User
app.get('/logout', (req, res) => {
    res.clearCookie('token');
    res.redirect('/');
});

// Render Login Page
app.get('/login', (req, res) => {
    res.render('login.ejs');
});


// Signup Route
app.post('/signup', async (req, res) => {
    try {
        const { age, gender, password, name, phone, email, role } = req.body;

        // Hash password
        const salt = await bcrypt.genSalt(10);
        const hash = await bcrypt.hash(password, salt);

        // Create user
        const newUser = await usermodel.create({
            password: hash,
            age,
            gender,
            email,
            name,
            phone,
            role
        });

        // Generate JWT Token
        const token = jwt.sign({ id: newUser._id, role: newUser.role }, process.env.JWT_SECRET, { expiresIn: '1h' });
        res.cookie('token', token, { httpOnly: true });

        res.redirect('/worker');
    } catch (error) {
        console.error('Error creating user:', error);
        res.status(500).send('Error creating user');
    }
});

// Signup Page
app.get('/signup', (req, res) => {
    res.render('signup.ejs');
});



app.get('/worker', authMiddleware, async (req, res) => {
    try {
        const userId = req.user.id; 
        const user = await usermodel.findOne({ _id: userId }).lean();
        const jobs = await jobpostmodel.find().lean(); // Make sure it's an array

        if (!user) {
            return res.status(404).send('User not found');
        }
        
        res.render('worker-dashboard.ejs', { user, jobs }); // Pass `jobs` (plural)
    } catch (error) {
        console.error("Error fetching user:", error);
        res.status(500).send('Internal Server Error');
    }
});





app.get('/client', authMiddleware, async (req, res) => {
    try {
        const userId = req.user.id; 
        const jobPosts = await jobpostmodel.find({ user: userId }).populate('user');

        res.render('client-dashboard.ejs', { jobPosts });
    } catch (error) {
        console.error('Error fetching job posts:', error);
        res.status(500).send('Error fetching job posts');
    }
});



//jobpost page 

app.post('/post_job', authMiddleware, async (req, res) => {
    try {
        
        // Destructure the data from the request body
        const {
            eventTitle,
            jobDescription,
            paymentBudget,
            eventDuration,
            eventLocation,
            dressCode,
            minAge,
            maxAge,
            maleStaff,
            femaleStaff,
            additionalRequirements,
            user,
        } = req.body;
        const userId = req.user.id; 
        // Create a new job post
        const newJobPost = await jobpostmodel.create({
            eventTitle,
            jobDescription,
            paymentBudget,
            eventDuration,
            eventLocation,
            dressCode,
            ageRange: { minAge, maxAge },
            staffGenderRequirements: { maleStaff, femaleStaff },
            additionalRequirements,
            user: userId,
        });
        
        // Respond with success message and job post data
        res.redirect('client')
    } catch (error) {
        console.log(error);
        
        res.status(500).json({ message: "Error creating job post", error });
    }
});


app.get('/post_job', (req, res) => {
    res.render('post_job.ejs');
});

// worker job page 

app.get('/worker_job', (req, res) => {
    res.render('worker-jobs.ejs');
});



module.exports.handler = serverless(app);


// Start Server
app.listen(3000);