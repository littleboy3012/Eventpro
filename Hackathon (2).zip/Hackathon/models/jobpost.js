const mongoose = require('mongoose');

const jobpostSchema = new mongoose.Schema({
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'user', required: true } ,
    eventTitle: {
        type: String,
        required: true,
        trim: true,
    },
    jobDescription: {
        type: String,
        required: true,
        trim: true,
    },
    paymentBudget: {
        type: Number,
        required: true,
        min: 1,
    },
    eventDuration: {
        type: Number,
        required: true,
        min: 1,
    },
    eventLocation: {
        type: String,
        required: true,
        trim: true,
    },
    dressCode: {
        type: String,
        required: true,
        enum: ['formal', 'semi-formal', 'casual', 'traditional', 'custom', 'business-casual', 'smart-casual'],
    },
    ageRange: {
        minAge: {
            type: Number,
            required: true,
            min: 18,
        },
        maxAge: {
            type: Number,
            required: true,
            min: 18,
        },
    },
    staffGenderRequirements: {
        maleStaff: {
            type: Number,
            default: 0, 
        },
        femaleStaff: {
            type: Number,
            default: 0, 
            min: 0,
        },
    },
    additionalRequirements: {
        type: String,
        trim: true,
        default: '',
    },
    postedAt: {
        type: Date,
        default: Date.now,
    },
});

module.exports = mongoose.model('jobpost', jobpostSchema);

